#!/usr/bin/env python3
"""
Créer un favicon OACA plus visible et distinctif
"""

try:
    from PIL import Image, ImageDraw, ImageFont
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

def create_distinctive_oaca_favicon():
    """Créer un favicon OACA très distinctif"""
    if not PIL_AVAILABLE:
        print("❌ PIL/Pillow requis")
        return False
    
    # Créer une image 32x32 avec fond bleu OACA
    img = Image.new('RGBA', (32, 32), (46, 95, 138, 255))  # Fond bleu OACA
    draw = ImageDraw.Draw(img)
    
    # Couleurs
    white = (255, 255, 255, 255)
    blue_light = (74, 144, 226, 255)
    yellow = (255, 215, 0, 255)  # Accent doré
    
    # Bordure blanche
    draw.rectangle([1, 1, 30, 30], outline=white, width=1)
    
    # Cercle central blanc
    draw.ellipse([8, 6, 24, 18], fill=white, outline=blue_light, width=1)
    
    # Texte OACA en gras
    try:
        font = ImageFont.load_default()
        # Texte "O" en haut à gauche
        draw.text((4, 20), "O", fill=white, font=font)
        # Texte "A" en haut à droite  
        draw.text((12, 20), "A", fill=white, font=font)
        # Texte "C" en bas à gauche
        draw.text((20, 20), "C", fill=white, font=font)
        # Texte "A" en bas à droite
        draw.text((28, 20), "A", fill=yellow, font=font)
    except:
        # Points de couleur si le texte ne fonctionne pas
        draw.ellipse([6, 22, 10, 26], fill=white)
        draw.ellipse([12, 22, 16, 26], fill=white)
        draw.ellipse([18, 22, 22, 26], fill=white)
        draw.ellipse([24, 22, 28, 26], fill=yellow)
    
    # Lignes d'aviation
    draw.line([4, 12, 12, 12], fill=white, width=2)
    draw.line([20, 12, 28, 12], fill=white, width=2)
    draw.line([14, 10, 18, 10], fill=yellow, width=2)
    draw.line([14, 14, 18, 14], fill=yellow, width=2)
    
    # Sauvegarder
    img.save('favicon_oaca_new.png', 'PNG')
    img.save('favicon_oaca_new.ico', 'ICO')
    print("✅ Nouveau favicon OACA créé!")
    
    # Créer aussi les icônes PWA
    for size in [192, 512]:
        large_img = img.resize((size, size), Image.Resampling.NEAREST)
        large_img.save(f'Icon-{size}_new.png', 'PNG')
        print(f"✅ Icône {size}x{size} créée")
    
    return True

if __name__ == "__main__":
    print("🎨 Création d'un favicon OACA distinctif...")
    create_distinctive_oaca_favicon()
    print("🚀 Nouveau favicon prêt !")
