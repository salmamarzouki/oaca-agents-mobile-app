#!/usr/bin/env python3
"""
Créer un favicon basé sur le vrai logo OACA officiel
"""

try:
    from PIL import Image, ImageDraw, ImageFont
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

def create_official_oaca_favicon():
    """Créer un favicon basé sur le logo OACA officiel"""
    if not PIL_AVAILABLE:
        print("❌ PIL/Pillow requis")
        return False
    
    # Créer une image 32x32 avec fond blanc
    img = Image.new('RGBA', (32, 32), (255, 255, 255, 255))
    draw = ImageDraw.Draw(img)
    
    # Couleurs du logo OACA officiel
    blue_main = (41, 128, 185)     # Bleu principal du logo
    blue_light = (52, 152, 219)   # Bleu clair
    blue_dark = (31, 97, 141)     # Bleu foncé
    
    # Dessiner les courbes stylisées du logo OACA
    # Courbe principale (simplifiée pour favicon)
    draw.arc([4, 4, 20, 20], 0, 180, fill=blue_main, width=2)
    draw.arc([6, 6, 18, 18], 0, 180, fill=blue_light, width=1)
    
    # Courbes intérieures
    draw.arc([8, 8, 16, 16], 0, 90, fill=blue_dark, width=1)
    draw.arc([10, 10, 14, 14], 90, 180, fill=blue_main, width=1)
    
    # Lignes horizontales représentant l'aviation
    draw.line([20, 8, 28, 8], fill=blue_main, width=2)
    draw.line([20, 12, 26, 12], fill=blue_light, width=1)
    draw.line([20, 16, 24, 16], fill=blue_dark, width=1)
    
    # Texte OACA simplifié
    try:
        font = ImageFont.load_default()
        draw.text((16, 22), "OACA", fill=blue_dark, anchor="mm", font=font)
    except:
        # Points si le texte ne fonctionne pas
        draw.ellipse([6, 24, 8, 26], fill=blue_main)
        draw.ellipse([12, 24, 14, 26], fill=blue_main)
        draw.ellipse([18, 24, 20, 26], fill=blue_main)
        draw.ellipse([24, 24, 26, 26], fill=blue_main)
    
    # Bordure subtile
    draw.rectangle([0, 0, 31, 31], outline=blue_light, width=1)
    
    # Sauvegarder
    img.save('favicon_oaca_official.png', 'PNG')
    img.save('favicon_oaca_official.ico', 'ICO')
    print("✅ Favicon OACA officiel créé!")
    
    # Créer les icônes PWA avec plus de détails
    for size in [192, 512]:
        large_img = Image.new('RGBA', (size, size), (255, 255, 255, 255))
        large_draw = ImageDraw.Draw(large_img)
        
        # Échelle pour la grande taille
        scale = size // 32
        
        # Courbes principales agrandies
        large_draw.arc([4*scale, 4*scale, 20*scale, 20*scale], 0, 180, fill=blue_main, width=3*scale)
        large_draw.arc([6*scale, 6*scale, 18*scale, 18*scale], 0, 180, fill=blue_light, width=2*scale)
        
        # Courbes intérieures
        large_draw.arc([8*scale, 8*scale, 16*scale, 16*scale], 0, 90, fill=blue_dark, width=2*scale)
        large_draw.arc([10*scale, 10*scale, 14*scale, 14*scale], 90, 180, fill=blue_main, width=2*scale)
        
        # Lignes d'aviation
        large_draw.line([20*scale, 8*scale, 28*scale, 8*scale], fill=blue_main, width=4*scale)
        large_draw.line([20*scale, 12*scale, 26*scale, 12*scale], fill=blue_light, width=2*scale)
        large_draw.line([20*scale, 16*scale, 24*scale, 16*scale], fill=blue_dark, width=2*scale)
        
        # Texte OACA plus grand
        try:
            # Essayer d'utiliser une police plus grande
            font_size = max(12, size // 16)
            font = ImageFont.load_default()
            large_draw.text((size//2, 22*scale), "OACA", fill=blue_dark, anchor="mm", font=font)
            
            # Texte arabe simplifié
            large_draw.text((size//2, 26*scale), "ديوان الطيران المدني", fill=blue_light, anchor="mm", font=font)
            
            # Texte français
            large_draw.text((size//2, 28*scale), "OFFICE DE L'AVIATION CIVILE", fill=blue_main, anchor="mm", font=font)
        except:
            # Points de couleur si le texte ne fonctionne pas
            for i, color in enumerate([blue_main, blue_light, blue_dark, blue_main]):
                x = (6 + i*6) * scale
                y = 24 * scale
                large_draw.ellipse([x, y, x+2*scale, y+2*scale], fill=color)
        
        # Bordure
        large_draw.rectangle([0, 0, size-1, size-1], outline=blue_light, width=2*scale)
        
        large_img.save(f'Icon-{size}_official.png', 'PNG')
        large_img.save(f'Icon-maskable-{size}_official.png', 'PNG')
        print(f"✅ Icône officielle {size}x{size} créée")
    
    return True

if __name__ == "__main__":
    print("🎨 Création du favicon OACA officiel...")
    create_official_oaca_favicon()
    print("🚀 Favicon OACA officiel prêt !")
