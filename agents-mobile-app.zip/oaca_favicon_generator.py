#!/usr/bin/env python3
"""
Générateur de favicon OACA
Crée un favicon personnalisé pour l'application OACA Agents
"""

try:
    from PIL import Image, ImageDraw, ImageFont
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
    print("PIL/Pillow non disponible. Installation requise: pip install Pillow")

def create_oaca_favicon():
    """Créer un favicon OACA personnalisé"""
    if not PIL_AVAILABLE:
        print("❌ PIL/Pillow requis pour créer le favicon")
        return False
    
    # Créer une image 32x32 avec fond blanc
    img = Image.new('RGBA', (32, 32), (255, 255, 255, 255))
    draw = ImageDraw.Draw(img)
    
    # Couleurs OACA
    blue_dark = (46, 95, 138)    # #2E5F8A
    blue_medium = (53, 122, 189) # #357ABD
    blue_light = (74, 144, 226)  # #4A90E2
    
    # Dessiner un cercle principal
    draw.ellipse([8, 4, 20, 16], outline=blue_medium, width=2)
    
    # Dessiner des lignes horizontales (pistes)
    draw.line([22, 8, 28, 8], fill=blue_dark, width=2)
    draw.line([22, 10, 27, 10], fill=blue_medium, width=1)
    draw.line([22, 12, 26, 12], fill=blue_light, width=1)
    
    # Essayer d'ajouter du texte
    try:
        # Utiliser une police par défaut
        font = ImageFont.load_default()
        draw.text((16, 20), "OACA", fill=blue_dark, anchor="mm", font=font)
    except:
        # Si la police ne fonctionne pas, dessiner des points
        draw.ellipse([12, 22, 14, 24], fill=blue_dark)
        draw.ellipse([16, 22, 18, 24], fill=blue_dark)
        draw.ellipse([20, 22, 22, 24], fill=blue_dark)
    
    # Sauvegarder comme PNG
    img.save('favicon.png', 'PNG')
    print("✅ Favicon OACA créé: favicon.png")
    
    # Créer aussi des icônes pour PWA
    for size in [192, 512]:
        large_img = img.resize((size, size), Image.Resampling.LANCZOS)
        large_img.save(f'Icon-{size}.png', 'PNG')
        print(f"✅ Icône {size}x{size} créée: Icon-{size}.png")
    
    return True

def create_simple_favicon():
    """Créer un favicon simple sans PIL"""
    # Créer un fichier SVG simple
    svg_content = '''<?xml version="1.0" encoding="UTF-8"?>
<svg width="32" height="32" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
  <rect width="32" height="32" fill="white"/>
  <rect x="2" y="2" width="28" height="28" fill="none" stroke="#2E5F8A" stroke-width="1"/>
  <circle cx="16" cy="10" r="4" fill="none" stroke="#4A90E2" stroke-width="1"/>
  <line x1="22" y1="8" x2="28" y2="8" stroke="#357ABD" stroke-width="2"/>
  <line x1="22" y1="10" x2="27" y2="10" stroke="#357ABD" stroke-width="1"/>
  <line x1="22" y1="12" x2="26" y2="12" stroke="#357ABD" stroke-width="1"/>
  <text x="16" y="24" text-anchor="middle" font-family="Arial" font-size="6" fill="#2E5F8A" font-weight="bold">OACA</text>
</svg>'''
    
    with open('favicon.svg', 'w', encoding='utf-8') as f:
        f.write(svg_content)
    
    print("✅ Favicon SVG créé: favicon.svg")
    return True

if __name__ == "__main__":
    print("🎨 Création du favicon OACA...")
    
    if PIL_AVAILABLE:
        create_oaca_favicon()
    else:
        create_simple_favicon()
        print("💡 Pour un meilleur résultat, installez Pillow: pip install Pillow")
    
    print("🚀 Favicon OACA prêt !")
